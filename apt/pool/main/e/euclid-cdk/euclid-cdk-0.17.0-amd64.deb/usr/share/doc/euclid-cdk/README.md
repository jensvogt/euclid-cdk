# euclid-cdk

The C++ SDK for a [euclid](https://github.com/jensvogt/euclid) server, alongside euclid-jdk (Java),
euclid-pdk (Python) and euclid-ndk (Node.js).

It covers **EAM** — euclid's access management module — which is where a login comes from, the two
**request-signing schemes** a euclid client authenticates with, and every module reached through the
session a login answers with: **ESM** (storage), **EQS** (queues), **ENS** (notifications), **EKM**
(keys and certificates), **EKV** (tables of items), **ESS** (secrets), **ETS** (the FTP and SFTP
endpoints onto a bucket), **EMO** (monitoring, including a metrics registry an application records
into), **EAP** (the applications euclid runs), **EAG** (the API gateway that publishes them),
**EES** (the event service — how something outside euclid watches what happens inside it), **EAD**
(the audit trail) and **EMM** (the module manager, which is every module's live process pool).

That is all of euclid. For an action this SDK does not name — one newer than the release you have —
`CDK::ModuleClient` is what a module client is built out of, and `EAM::Session::NewRequest()` and
`CDK::HttpClient` reach any action at all.

Both a **shared** and a **static** library are built: `libeuclid-cdk.so` and `libeuclid-cdk.a`.

## Using it

```cpp
#include <euclid/cdk/Euclid.h>

using namespace Euclid::CDK;

const auto session = EAM::Eam::ForServer("https://euclid.example.com")
                             .Credentials("jens", "secret")
                             .Login();

for (const auto page = session.ListUsers({.prefix = "j", .pageSize = 25}); const auto &user: page.items) {
    std::cout << user.userId << " " << user.email << "\n";
}

const ESM::Esm esm(session);
const auto bucket = esm.CreateBucket("reports");
esm.UploadFile(bucket.ern, "2026/q3.pdf", "q3.pdf");
```

`Login()` reuses a still-valid session out of `~/.euclid/credentials`, so calling it repeatedly costs
nothing after the first time — and that file is shared with euclid-cli and the other SDKs, so a login
from any of them is picked up here. `UseCache(false)` forces a fresh login.

### Installing it

Every release carries plain archives and an installer per platform:

| file | installs to |
|---|---|
| `euclid-cdk-<version>-amd64.deb` | `/usr` |
| `euclid-cdk-<version>-x86_64.rpm` | `/usr` |
| `euclid-cdk-<version>-macos-arm64.pkg` | `/usr/local` |
| `euclid-cdk-<version>-windows-x64.msi` | `C:\Program Files\euclid-cdk` |

Each one carries the headers, both libraries, the CMake package config, the licence and the README —
the same tree the archives hold, laid out where each platform looks for it. The MSI also appends its
install folder to the system `CMAKE_PREFIX_PATH`, so `find_package(euclid-cdk)` finds it without
being told where it is; the DEB, RPM and pkg install under a prefix CMake already searches.

Boost and OpenSSL are not dependencies of any of them: the release build links both statically, so
they are inside the library rather than beside it.

On Linux the package managers are the better route — the repositories below keep every release, so
an upgrade is an `apt upgrade` rather than finding the next `.deb` by hand.

#### With apt, on Debian and Ubuntu

Every release is published to a signed APT repository, so updates arrive with an ordinary
`apt upgrade` rather than a download:

```bash
curl -fsSL https://jensvogt.github.io/euclid-cdk/euclid-cdk.gpg.asc -o /tmp/euclid-cdk.asc
sudo gpg --dearmor --yes -o /usr/share/keyrings/euclid-cdk.gpg /tmp/euclid-cdk.asc

echo "deb [signed-by=/usr/share/keyrings/euclid-cdk.gpg] https://jensvogt.github.io/euclid-cdk/apt stable main" \
  | sudo tee /etc/apt/sources.list.d/euclid-cdk.list
sudo apt update
sudo apt install euclid-cdk
```

The download and the key import are two commands rather than a pipeline, and deliberately so: in
`curl … | sudo gpg --dearmor -o <file>` it is *gpg* that creates the file, so a download that fails
still leaves a keyring behind — an empty one. `apt update` then reports `NO_PUBKEY` and the fault
looks like the repository rather than the key that never arrived. Downloading first means a failure
stops before anything is written.

The repository keeps every release, so a particular one can be asked for by name —
`sudo apt install euclid-cdk=0.16.0`.

#### With yum or dnf, on RHEL and Fedora

```bash
sudo curl -fsSL https://jensvogt.github.io/euclid-cdk/euclid-cdk.repo \
  -o /etc/yum.repos.d/euclid-cdk.repo
sudo yum install euclid-cdk
```

That file sets both `gpgcheck` and `repo_gpgcheck`, which are two different claims: that the package
is ours, and that the index listing it is. The RPM carries its own signature, so the first is checked
against the package itself rather than against a promise made by the repository.

Nothing signs the `.deb`, and nothing needs to: APT's chain runs from the signed `Release` file to
the `Packages` index to each package's checksum, so tampering with any link is what `apt update`
reports.

**Verifying a download.** The release carries `SHA256SUMS`, a detached signature for it, and the
public key — the same key [euclid-rui](https://github.com/jensvogt/euclid-rui) signs its APT
repository with, so one trusted key covers both:

```bash
gpg --import euclid-cdk.gpg.asc
gpg --verify SHA256SUMS.asc SHA256SUMS
sha256sum --ignore-missing -c SHA256SUMS
```

The RPM additionally carries an in-package signature, which `rpm -K` checks once that key is in the
RPM keyring.

Two things the signatures do **not** do. The MSI is not signed with Authenticode and the pkg is not
signed for Gatekeeper — both need a certificate from the respective vendor, which this project does
not have — so Windows SmartScreen and macOS will each warn before installing. The GPG signature is
what actually establishes where a file came from, and it has to be checked by hand.

### Building against it

```cmake
find_package(euclid-cdk CONFIG REQUIRED)
target_link_libraries(my-app PRIVATE euclid::cdk)         # shared
target_link_libraries(my-app PRIVATE euclid::cdk-static)  # static
```

The same two names work when this project is added with `add_subdirectory()`.

## What it does

### Login and the session

`EAM::Eam` is the login builder; `EAM::Session` is what it answers with, and every EAM operation
hangs off that. The split exists because logging in and being logged in need different arguments.

```cpp
auto session = EAM::Eam::ForServer(url)
                       .Credentials("jens", "secret")
                       .Namespace("reports")             // applied after login, like eam login --namespace
                       .Scheme(SigningScheme::SigV4())   // RFC 9421 unless asked otherwise
                       .Auth(EAM::AuthMode::Signature)   // Auto, Signature or Bearer
                       .CaCertPath("/etc/euclid/euclid_cert.crt")
                       .Timeout(std::chrono::seconds(10))
                       .Login();
```

The session covers users, groups, accounts, namespaces, roles, grants, access keys, passwords,
email addresses and metrics. `ListMyAccounts()` answers the narrower question a client actually has
— which accounts this session may work in — where `ListAccounts()` is the installation and
administrator-only. `RefreshSession()` takes a fresh token on the strength of the current one and
answers exactly what a login answers, but does **not** adopt it: replacing this session's token is a
decision about the object rather than something a call that reads should take. The OIDC and SAML browser flows are the one part of EAM it does not wrap — those are
redirects through an identity provider rather than calls a library makes. `Session::Call()` sends any
action by name, both for those and for one that arrives in a later euclid than this SDK.

A **role** is a name over a set of permissions, written down once instead of at every grant:
`CreateRole()`, `UpdateRole()`, `GetRole()`, `ListRoles()`, `DeleteRole()`. Three things about them
differ from the rest of the session. `UpdateRole()` *replaces* the permissions rather than merging,
which is the only way to narrow a role. `ListRoles()` puts the built-ins first and outside the
paging — they aren't stored, so there is no page to put them on — which is why the total can be
smaller than the number of items. And `DeleteRole()` is refused while the role is still granted,
rather than cascading and leaving grants that quietly do nothing.

`ChangePassword()` is two operations under one name, and which one it is depends on the user it names
rather than on what it sends: your own needs the old password, somebody else's needs administrator
rights. A wrong old password answers `403` and not `401`, deliberately — every euclid client reads
`401` as "your session is gone" and logs out, which is a poor answer to a typo.

### Asking whether something is there

Most modules answer a plain existence question: `Esm::ExistsBucket()`, `Eqs::ExistsQueue()`,
`Ens::ExistsTopic()`, `Ekm::ExistsKey()`, `Ekv::ExistsTable()` and `Ess::ExistsSecret()`.

```cpp
if (!esm.ExistsBucket("reports")) esm.CreateBucket("reports");
```

They have **three** answers, not two. `true` and `false` are the ones a caller expects; the third is
a `ServiceError`, and it is the one that matters. An expired session, an unreachable gateway or a
refused permission is not the same as "not there", and returning false for those would have callers
deleting and recreating things over an outage — so only an HTTP `404` becomes `false`, and everything
else is rethrown.

`ExistsSecret()` asks `ListSecrets()` rather than `GetSecret()`, deliberately: `GetSecret()` answers
with the decrypted value, so asking it this question would mean holding permission to *read the
password* rather than to know the name is taken, decrypting it, carrying the plaintext back over the
wire, and leaving an audit entry indistinguishable from somebody actually reading it. None of that is
part of the question.

### Storage

`ESM::Esm` is built from a session that has already logged in, and holds it rather than a copy of
what it knew at the time — so a `ChangeNamespace()` between two calls scopes the second one. It
covers buckets, objects, object attributes, subscriptions, encryption and the transfers.

```cpp
const ESM::Esm esm(session);

esm.PutObject(bucketErn, "notes/hello.txt", "written in one request\n",
              {.attributes = {{"author", "jens"}, {"revision", 1L}}});

esm.UploadFile(bucketErn, "data/large.bin", "large.bin", {.partSize = 8 * 1024 * 1024});
esm.DownloadFile(bucketErn, "data/large.bin", "copy.bin");
```

An object's attributes are typed: `COM::Variant` is a port of the server's own, so an attribute
stored as a `long` comes back as a `long` rather than as whatever JSON's one number type reads as.
A plain value is tagged with the type it is written as, which is why `1L` above is a long and `1`
would be an int; the two are different columns in euclid.

Four actions — `put-object`, `get-object`, `upload-part` and `download-part` — carry the object's
bytes themselves, with the bucket, the key and the part number riding as headers instead of in a
body, which is what keeps a 5 MiB part 5 MiB on the wire rather than a third larger as base64 inside
JSON. Those four also present the session's bearer token rather than a signature, which is what
euclid-cli and the other SDKs do for the same four, so every client writes objects the same way; a
session that asked for `AuthMode::Signature` signs them anyway.

`UploadFile()` and `DownloadFile()` send their parts from several threads and retry a step that
failed transiently, because a transfer is long and giving up on one part of it throws away
everything already transferred. A download is tried in one request first and falls back to the
multipart path when the server answers "too large", so a caller does not have to know which of the
two an object needs. Everything else is one request at a time, like the session.

#### Versions, lifecycle and archives

A bucket can keep what a key used to hold, and move what nobody reads any more off the disk:

```cpp
std::ignore = esm.SetBucketVersioning(bucket.ern, true);
std::ignore = esm.SetBucketLifecycle(bucket.ern, {{.id = "cold", .archiveAfterDays = 90, .restoreDays = 7}});
```

Versioning is off by default, because keeping every version costs disk for as long as the bucket
exists. Turning it *off* leaves what was already kept, so `ListObjectVersions()` still reads it —
and a key whose current object was deleted still lists its versions, which is what makes a deletion
recoverable.

Lifecycle rules say what to archive and when. They are **replaced** rather than merged, and the whole
set is validated before any of it is stored, so a bucket never ends up with half a set. Rules decide
what to archive, never what to bring back: `RestoreObject()` is the only way back, and it is
*temporary* — `ObjectLifecycle::restoredUntil` is when it goes away again, which matters because a
restore that expires while something is still reading looks exactly like the object vanishing.
`ArchiveObject()` needs no rule; it is what an operator does to something they know is not wanted
online.

`StopBucket()` holds the bucket's **events** and leaves the objects alone — it is not a way to make a
bucket read-only. Everything held goes out when it starts, so a bucket stopped for an hour delivers
an hour of events at once.

`VerifyObjects()` checks records against the files behind them — a stat per object, never the bytes —
and finds the damage nothing else notices until a download fails. It pages: `VerifyResult::nextKey`
is where the next pass starts.

### Queues and topics

`EQS::Eqs` and `ENS::Ens` are built from a session the same way, and are the two halves of euclid's
messaging: a queue holds a message until a consumer takes it, and a topic hands each message to
every subscriber and keeps it as a record of having done so.

```cpp
const EQS::Eqs eqs(session);

const auto queue = eqs.CreateQueue("orders");
eqs.SendMessage(queue.ern, R"({"order": 17})", {.attributes = {{"tenant", "acme"}}});

for (const auto &message: eqs.ReceiveMessages(queue.ern, {.waitTime = std::chrono::seconds(20)}).items) {
    handle(message.body);
    eqs.DeleteMessage(message.receiptHandle);     // after the work, not before
}
```

Receiving is a lease rather than a read: a message a consumer takes is invisible to every other
consumer until its visibility timeout expires, and deleting it with the receipt handle is what says
the work was done. A consumer that dies instead simply stops holding the lease, and the message
comes back.

`waitTime` is a long poll the **server** holds open, so an idle queue costs one request for the
whole window rather than one per tick, and a message arrives the instant it is sent. With no wait
asked for, the queue's depth is checked first and an empty queue costs no receive at all — a receive
is a write. The one case that loops is the server declining to wait, which it does when it has no
long-poll slot free; then the client waits a moment before asking again, since a server short of
threads does not need to be asked more often.

```cpp
const ENS::Ens ens(session);

const auto topic = ens.CreateTopic("order-events");
ens.Subscribe(topic.ern, queue.ern);              // every message from now on lands on the queue
ens.PublishMessage(topic.ern, R"({"order": 18})");
```

`StopTopic()` holds delivery without refusing publishers — what arrives meanwhile is kept and fanned
out when the topic is started again, which is what a subscriber being redeployed asks for — and
`SetTopicRetention()` says how long a published message is kept at all, since a topic is fanned out
at publish time and nothing else would ever remove it. Its two named values are
`ENS::InstallationRetention` (0), which follows `euclid.modules.ens.retention-period` as that
changes, and `ENS::RetentionForever` (-1), which is not a very long period but the absence of one —
the server stores such a message with no expiry, which is what its TTL index ignores, so the topic
grows without limit and only `PurgeTopic()` empties it.

Three things a queue or a topic is created with can be changed afterwards rather than only at
creation: `Eqs::SetQueueDelay()`, `Eqs::SetQueueMaxMessageLength()` and
`Ens::SetTopicMaxMessageLength()`. Each applies to what is sent from then on — a message already
waiting keeps the release time it was given, and one already stored was measured against the limit
in force when it arrived. The two length limits read the same zero differently, which is the
server's rule rather than a slip: a queue with `EQS::InstallationMaxMessageLength` has no limit of
its own and is measured against the installation's figure, while a topic that accepts nothing is
refused outright — holding a topic for a while is what `StopTopic()` is for, and it is reversible.

Two smaller things worth knowing. `Eqs::AsInternal()` is a view of the client whose requests are
marked as euclid's own traffic, for the polling that measures a system rather than uses it; without
it, instrumentation keeps a pool permanently awake and makes an idle module look busy.
And `PurgeAllQueues()` covers every namespace of the account while `PurgeAllTopics()` follows the
session's namespace — the two differ because each keeps the default it shipped with, in every SDK.

### Keys and certificates

`EKM::Ekm` holds encryption keys and the certificates a deployment serves. Key material never leaves
the server: encrypting sends the bytes to the key rather than fetching the key to the bytes.

```cpp
const EKM::Ekm ekm(session);

const auto key = ekm.CreateKey({.description = "customer exports"});
const auto sealed = ekm.Encrypt(key.name, "account 4711");
const auto plain  = ekm.Decrypt(key.name, sealed);
```

A key is named two ways and they are not interchangeable: `name` is the ID the server minted, and is
what encrypts, decrypts and is deleted; the ERN is what revokes, describes and tags. Both are on
every `Key` a listing returns.

`DeleteKey()` schedules rather than deletes — everything the key encrypted becomes unreadable when
the date passes, and the window is the only chance anybody gets to notice. `RevokeKey()` is the one
to reach for when a key should no longer be used but the data under it is still wanted: a revoked
key stops encrypting and goes on decrypting. There is no `Metrics()` here, unlike every other
module: EKM's server answers `get-metrics` with a 404, so `Call()` is where that would live.

### Tables

`EKV::Ekv` is a key-value store: tables of items, read by key rather than searched.

```cpp
const EKV::Ekv ekv(session);
ekv.CreateTable("sessions", "userId", {.sortKey = "startedAt", .sortKeyType = std::string(EKV::KeyNumber)});

ekv.PutItem("sessions", {{"userId", "jens"}, {"startedAt", 1757462400}, {"host", "laptop"}});
const auto recent = ekv.Query("sessions", "jens", {.sortOperator = std::string(EKV::SortGe),
                                                   .sortValue = 1757462400});
```

A table is keyed on one attribute or two: a partition key that identifies an item, and optionally a
sort key that orders the items sharing one — which is what makes a partition readable as a range.
Only the keys have declared types, and the type is what a comparison is made under: a `KeyNumber`
sort key orders 2, 9, 10, 100 rather than putting `"10"` before `"9"`.

Everything else about an item is free-form JSON — `boost::json::object` in and out, not the tagged
`COM::Variant` that EQS, ENS and ESM attributes use, because EKV stores documents rather than typed
attribute maps. `Item::attributes` is what to pass straight back to `PutItem()`: the server keeps an
item's timestamps among its attributes as `_created` and `_modified`, and this SDK lifts them out —
a write replaces rather than merges, so leaving them in would make an item that was read, changed
and written back grow two attributes it never had.

`GetItem()` throws on a miss and `FindItem()` answers an empty `std::optional` instead; only a 404
becomes empty, since a refusal or a malformed key does not mean "not there". `Query()` addresses a
partition, which is what EKV is for; `Scan()` reads the table, which is for an export rather than a
lookup.

### Secrets

`ESS::Ess` keeps values encrypted under an EKM key and hands them back one at a time.

```cpp
const ESS::Ess ess(session);

ess.CreateSecret("db-password", "hunter2", {.description = "the reporting database"});
const auto password = ess.GetSecret("db-password").value;
```

`GetSecret()` is the only call that answers with a value — listing, rotating and tagging all answer
with metadata alone, so those can be logged and printed without being the thing that leaks it. The
value's life is tied to the key's: deleting that key in EKM is what makes the value unrecoverable,
whatever ESS still says about the secret.

`UpdateSecret()` takes `std::optional` fields for the same reason `ETS::Ets::UpdateServer()` does —
an unset description leaves the stored one alone, an empty one clears it. A value is the exception:
the server refuses an empty one, so this does too, one round trip earlier. Naming a `keyErn` moves
the secret onto that key, which is how one is taken off a key being retired; that is not a rotation,
and only a new value bumps the version.

### Applications

`EAP::Eap` is what euclid runs, from what, and as whom.

```cpp
const EAP::Eap eap(session);

eap.CreateApplication("order-service", std::string(EAP::RuntimeBinary), "artifacts", "order-service-1.4.0",
                      {.queues = {"orders"}, .maxInstances = 4});
eap.StartApplication("order-service");
```

An application is deployed from an artifact already in a bucket — ESM puts it there, EAP names it.
The deployment says which buckets and queues it may reach, and euclid grants those to the identity
it runs as: a technical principal it creates for the application unless one is named, with no
password, no login and one access key. Nothing an application leaks is then a person's credential.

Starting is a desired state rather than a wait, as in ETS, so the application in the answer is
usually still `STOPPED`. `RestartApplication()` exists instead of a stop followed by a start because
between those two the desired state is stopped, and a caller that fails in between leaves the
application down.

`UpdateApplication()` takes `std::optional` fields — an unset command leaves the stored one alone,
an empty one hands the artifact back to the runtime's own interpreter. Two things there are worth
knowing: `buckets` and `queues` are re-resolved together, so naming one and not the other revokes
what the other granted (name both, or neither); and `nameSpace` is a *move* rather than a field
change, which is why unset and empty differ — empty moves the application back to the account root.

**`ReportLoad()` is the one call here an application makes about itself** rather than an
administrator making it about the application:

```cpp
// on a schedule, while the application works
eap.ReportLoad("order-service", {.utilisation = 42.5, .backlog = queue.size(), .active = inFlight});
```

The instance id comes from `EUCLID_INSTANCE_ID`, which euclid's manager sets for every process it
starts, so an application need not carry it around; `EAP::Eap::InstanceId()` reads it. The
application id is always sent, even though the server can infer it from a caller named
`app-<something>` — that inference only holds while an application's id and the identity it runs as
agree, and when they didn't, every report went to a pool that did not exist, answered `200`, and
left the autoscaler blind. Everything else in this module is administrator-only.

#### Nodes, egress and platforms

Three further areas of `EAP::Eap`, each with its own caller in mind.

**Nodes** are the hosts that run instances. A worker announces itself and renews on a lease:
`RegisterNode()`, then `RenewNode()` on a timer. `RegisterNode()` is idempotent and that matters — a
restarted worker has to come back as the node it was, or it abandons the instances it is still
running. `RenewNode()` returns the **whole** set of instances assigned to the node, not what changed,
so a worker reconciles against it; `AssignedInstance::revision` is what says an instance must be
replaced rather than left alone. `DrainNode()` is deliberately **not** a stop: a drained node keeps
what it runs and keeps renewing, and is only refused *new* placements, which is why draining is not
an outage. `DeleteNode()` releases the name's binding to its principal, and is administrator-only for
that reason.

**Egress** is for an application calling the outside world:

```cpp
if (const auto permit = eap.AcquireEgressPermit("downloads.example.com"); permit.granted) {
    // ... make the call ...
    std::ignore = eap.ReleaseEgressPermit("downloads.example.com", permit.permitId);
}
```

The point is that instances of one application share one budget — a limit kept in each process would
be multiplied by the pool size, which is how a fleet gets itself blocked. **A refusal is an ordinary
answer, not an exception**: branch on `granted` and wait `retryAfterMs`. `ReportEgressThrottled()`
turns one instance's `429` into the whole pool backing off. `SetEgressLimit()`, `DeleteEgressLimit()`
and `ListEgressSites()` are the administrative half; `EgressSite::limitsSet` is how to tell a site
with limits of its own from one showing the installation default.

**Platforms** are declarations with no application behind them — the shared queues, topics and
buckets that exist for everything rather than for one application. `ApplyPlatform()` runs the same
engine an application's declaration does, with `prune` deciding whether what the declaration no
longer names is deleted or merely reported under `InfrastructureResult::kept`. `PlanPlatform()` and
`PlanInfrastructure()` are the dry runs, and worth running before a release depends on a declaration:
the lists include what a full reconcile would **delete**.

`SetApplicationLimits()` sets the memory and CPU ceilings an instance runs under; `-1` leaves one
alone and `0` removes it. It is deliberately not part of an application's revision, so setting a
ceiling restarts nothing by itself. `RebalanceApplication()` asks for instances to be spread again
after a node joins or is drained — and refuses a job, because a job's instance is a *run* of it and
moving one would start it again.

### The API gateway

`EAG::Eag` publishes a path to the outside world and says what answers it. The gateway routes by
configuration rather than by convention, so the name of whatever serves a path never appears in the
URL a caller asks for — which is what lets an application be renamed, replaced or split across
several routes without anything calling it having to change.

```cpp
const EAG::Eag eag(session);

eag.CreateRoute("orders", "/orders", "order-service",
                {.methods = {std::string(EAG::MethodGet)}, .authentication = std::string(EAG::AuthEuclid)});
```

A route names exactly one of three things, and which one is its whole character — so there is a call
for each rather than one call with fields that contradict each other:

| call | what answers the path |
|---|---|
| `CreateRoute()` | an application EAP runs |
| `CreateModuleRoute()` | euclid itself — `("login", "/euclid/login", "eam", "login")` is how a browser logs in without a second origin and CORS between them |
| `CreateUploadRoute()` | a bucket: the body is streamed into ESM and nothing is forwarded |

Paths match as a prefix, because a REST resource is a tree, and the longer of two matching routes
wins — so a specific route can be carved out of a general one later without either being rewritten.
Two routes may share a path when their methods don't overlap, which is how reads and writes of one
resource go to different applications; an overlap is refused with `409` rather than decided by sort
order.

One action per module route, deliberately: a route for `/euclid` that passed its remaining segments
through as actions would publish every action the module has, including the ones that delete users.

`UpdateRoute()` takes `std::optional` fields, and `SetRouteActive()` is how something exposed by
mistake is withdrawn in a hurry and put back knowing it returns exactly as it was — an inactive route
still holds its path, so nothing else can claim it meanwhile. `ListListeners()` reports the ports
themselves: they are written in the installation's configuration rather than created here, so what it
answers is what the gateway is *doing* — `serving` false with listeners configured is a port that was
taken or a certificate that could not be loaded.

Two things this client does by leaving fields out rather than sending them: an unnamed namespace,
region or authentication is **absent** from the request, because the server falls back to its default
only for a field that is not there at all — an empty namespace would publish the route at the account
root instead of in the session's. And an upload route defaults to `AuthEuclid` where a proxy route
defaults to none, because an unauthenticated upload route is a public write endpoint into somebody's
bucket. Every action here is administrator-only.

### Transfer servers

`ETS::Ets` owns the FTP and SFTP endpoints onto a bucket — which protocol, which port, who may log
in, which bucket the files really live in. It never speaks either protocol itself; euclid's manager
turns a definition into a running process, and the process reads its definition back from here.

```cpp
const ETS::Ets ets(session);

ets.CreateServer("partner-drop", "invoices", 2222, {.userGroups = {"partners"}, .homeDirectory = "incoming/"});
ets.StartServer("partner-drop");
```

So a file uploaded over FTP is an object in a bucket, with the events and the lifecycle every other
object has. `desiredState` is what was asked for and `state` is what is observed running: the two
differing is a server starting up, and differing for long is one that cannot. Starting one only
writes the desired state, so the server in the answer is usually still `STOPPED`.

`UpdateServer()` takes `std::optional` fields because the server distinguishes a field being *sent*
from one that is not, rather than one value from another — an unset field leaves the stored one
alone, and an empty string replaces it. Every action here is administrator-only.

### Application monitoring

`EMO::Emo` is the monitoring module's client — `PushMetrics()`, and the administrator-only `List()`
and `Average()` for reading rows back. But an application does not want to push final numbers; it
wants to count things and time them and have something else do the arithmetic. euclid-jdk gets that
from Micrometer, and C++ has no Micrometer.

It does not need one. What Micrometer provides is two separable things — meters an application
records into, and a registry that accumulates them over a step and publishes the result — and
euclid's own C++ modules have done both for years with `Core::Monitoring`. `EMO::MeterRegistry` is
that, pushed through an authenticated session instead of a Unix socket:

```cpp
const EMO::Emo emo(session);
EMO::MeterRegistry metrics(emo, {.module = "invoice-parser", .commonLabels = {{"host", hostname}}});

const auto parsed   = metrics.CounterOf("invoices.parsed");
const auto rejected = metrics.CounterOf("invoices.parsed", {{"outcome", "rejected"}});
const auto duration = metrics.TimerOf("invoice.parse");
metrics.GaugeFrom("queue.depth", [&queue] { return static_cast<double>(queue.size()); });

for (const auto &invoice: incoming) {
    const EMO::ScopedTimer measure(duration);          // recorded however the scope is left
    Parse(invoice) ? parsed.Increment() : rejected.Increment();
}
```

A thread publishes every step (a minute by default) and nothing else has to be arranged; a step of
zero starts no thread and leaves `Publish()` to the application's own loop. What lands in EMO lands
in the same rows its own collectors write, and so in the same rollups, retention and graphs as CPU,
memory and the module gauges.

Three things are worth knowing, because each is a way a graph could otherwise lie:

- **A counter reports the step and starts again; a gauge reports what it reads and does not.** That
  is what makes a counter a *rate* to EMO, which sums it on rollup, and a gauge a *gauge*, which
  averages it. A counter pushed as a gauge is averaged into nonsense.
- **A timer becomes three series** — `name.count` and `name.total` as rates, `name.max` as a gauge,
  in milliseconds — under the same names euclid-jdk's Micrometer registry uses, so a C++
  application's timings graph beside a Java one's. There are no percentiles, because EMO stores one
  value per series per interval; a p99 would have to be a series of its own.
- **Labels are what split one series into several**, and every combination is a stored row per step
  forever. Decide them where the meter is created — a label carrying a request id is how a
  monitoring database fills up.

A push that fails is counted in `FailedPublishes()` and dropped rather than retried: a rate sent
twice is counted twice, and nothing here throws at the application, which does not stop because it
could not say how it was doing.

#### Alerts and dashboards

`EMO::Emo` also holds the alerting:

```cpp
std::ignore = emo.CreateAlertRule({.ruleId = "orders-slow", .name = "orders.latency",
                                   .statistic = std::string(EMO::StatisticMax),
                                   .comparison = std::string(EMO::ComparisonAbove),
                                   .critical = 500.0, .forPeriods = 3});
```

A rule watches a metric, optionally narrowed by labels, and is measured once per step of its
resolution. The two thresholds are independent and optional — a rule may warn without ever going
critical — and `forPeriods`/`clearPeriods` are what keep one noisy step from raising an alert.
`noDataAfterPeriods` covers the case thresholds cannot: **a series that stops arriving looks healthy
to anything that only tests thresholds**, so it gets its own level, `LevelNoData`.

`CreateAlertRule()` sends the whole rule, and an unset threshold travels as `null` — that is how the
server is told there is no threshold at that level. `UpdateAlertRule()` **merges**, so it sends only
what you set: read the rule, change what you mean, send it back.

`ListAlerts()` returns one entry *per series*, not per rule — a rule covering forty series has forty
entries, because the state belongs to the series. `ListAlertHistory()` answers what the current state
cannot: an alert that fired and cleared while nobody was looking leaves nothing in `ListAlerts()` and
a pair of entries in the history.

`ListMetrics()` is the catalogue behind a query — what names exist, which labels they carry, how many
series each has. It is the honest answer to "what is being recorded", which a listing cannot give
because it only confirms what it was already asked about.

Dashboards (`SaveDashboard()`, `GetDashboard()`, `ListDashboards()`, `DeleteDashboard()`) store a
layout as opaque JSON — EMO does not interpret it, and a listing carries names and times only.

### Watching what happens inside euclid

`EES::Ees` is the way out of euclid's internal event bus for something that is not a module. Where a
bucket subscription puts object events into a queue for one bucket, this reaches every event every
module publishes:

```cpp
const EES::Ees ees(session);
std::ignore = ees.Subscribe("indexer", {std::string(EES::ObjectCreated)});

for (;;) {
    const auto received = ees.ReceiveEvents("indexer", {.waitTime = std::chrono::seconds(20)});
    std::vector<std::string> done;
    for (const auto &event : received.events) {
        handle(event);
        done.push_back(event.eventId);
    }
    if (!done.empty()) std::ignore = ees.AckEvents("indexer", done);
}
```

**The subscriber name is the identity.** Every call names one rather than carrying a handle, and that
name owns the backlog — so two processes using one name are two consumers of one subscription, each
getting events the other does not. That is how a subscriber is scaled out, and a bug if it wasn't
meant.

A received event is *claimed*, not removed: invisible to anybody else until the visibility timeout
runs out, and only `AckEvents()` takes it away. So an event survives a subscriber that crashes
mid-handling and comes back with `Event::attempts` raised — which is why handling has to tolerate
seeing one twice. `ModeDurable` is the default; `ModeLive` drops what arrives while nobody is
listening, which suits a dashboard and nothing else.

A payload is left as JSON, because its shape belongs to whichever module published it.

### The audit trail

`EAD::Ead` reads what was run, by whom, in which account. It only reads: every module records its own
commands as it answers them, so there is no "record event" call and nothing an application has to do
to be audited — an audit whose write path ran through a separate module would be missing entries
exactly when that module was down.

```cpp
const auto page = ead.ListEvents({.module = "esm", .command = "delete-object", .pageSize = 50});
```

`ListEvents()` returns a **capped** total: `AuditPage::totalExact` false means "at least this many",
which is all a pager needs to know there is another page. An exact count on a trail of tens of
millions is seconds of database time beside a page of fifty, paid again on every page somebody turns
— `CountEvents()` is there when the number itself is the answer. `PurgeEvents()` requires a positive
window, and is itself recorded.

### Module processes

`EMM::Emm` is every module's live process pool. "Module" is wider than it sounds: euclid's own
services are modules, and so is every application pool EAP runs and every transfer server ETS runs.

```cpp
for (const auto &module : emm.ListModules().modules) {
    std::cout << module.name << " " << module.instances.size() << "\n";
}
```

`Module::core` separates euclid's own from the rest and decides what the control calls accept:
`StartModule()` and `StopModule()` are **refused for anything that is not core**, because an
application's or a transfer server's desired state belongs to EAP and ETS and anything recorded here
would be undone within seconds. `RestartModule()` works on all three — it changes no desired state,
so the same instances come straight back.

Nothing here waits; the manager acts on its next reconcile. Two sentinels are worth knowing:
`ModuleInstance::utilisation` and `backlog` read **-1** for an instance that has never reported,
which is not the same as one reporting no load, and the `desired…` limits read -1 for "nothing
pending" — without which a caller adjusting a limit twice would compute the second change from the
value the first has already replaced.

`ListBackups()` and `CreateBackup()` cover the archives the installation writes on its own schedule —
`BackupsResult` carries the schedule and retention as well as the files, so "why is there no backup
from last night" is answerable without reading the server's config. `CreateBackup()` does **not**
wait: it answers `202` with the name the archive will have, and `Backup::complete` false is a run
interrupted mid-write, left visible rather than cleaned away.

`Export()` and `Import()` move raw collection dumps and are answered unparsed: their shape belongs to
each module's own storage. Exporting EKM requires a passphrase, since it carries key material itself.

### Signing

A euclid client authenticates in one of two ways, and the server accepts either: a **bearer token**
from the login, or a **signature** made with the access key the login hands back.

| | `CDK::SigV4` | `CDK::HttpSignature` |
|---|---|---|
| Scheme | AWS Signature Version 4 | RFC 9421 HTTP Message Signatures |
| Presented in | `Authorization` | `Signature` / `Signature-Input` |
| Body bound through | `x-amz-content-sha256` | `Content-Digest` (RFC 9530) |
| Status | what euclid has always spoken | the standard replacement, and the default here |

Both are ports of the server's own `Core::SigV4` and `Core::HttpSignature`, kept line-for-line: what
a signature covers and how it is canonicalised is a wire format shared by the server, euclid-cli and
every SDK, and the two implementations have to agree byte for byte or nothing verifies. In
particular, `SigV4::SignedHeaderNames()` and `HttpSignature::CoveredComponents()` are fixed lists,
**order included** — neither is client-negotiated, so nothing in transit can narrow what a signature
actually covers and still have it verify.

Verification is here as well as signing. It is the only way to demonstrate that the two
canonicalisations are one canonicalisation, and a C++ service fronting euclid needs to check the
signatures it receives with the rules the server applies:

```cpp
if (const auto *scheme = SigningScheme::Of(request); scheme != nullptr) {
    const auto keyId = scheme->Verify(request, [](const std::string &id) { return secretOf(id); });
    if (!keyId.has_value()) return unauthorised();
}
```

Two notes worth carrying between implementations:

- **No `tag`.** euclid's server emits no RFC 9421 `tag` parameter and never looks at one, so a
  verifier that required a particular tag would reject the server's own signatures. One that arrives
  is accepted here and ignored.
- **`x-euclid-namespace` is not covered** by either scheme, knowingly and in every SDK. A namespace
  scopes what a request may touch, and the server checks it against the caller's grants rather than
  against the signature.

## Building

Dependencies are Boost (asio, beast, json, url) and OpenSSL — the same stack the euclid server
itself is built on. With vcpkg:

```bash
cmake -S . -B build -G Ninja \
      -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_TOOLCHAIN_FILE=/path/to/vcpkg/scripts/buildsystems/vcpkg.cmake
cmake --build build -j
ctest --test-dir build --output-on-failure
```

| Option | Default | |
|---|---|---|
| `EUCLID_CDK_BUILD_SHARED` | `ON` | build `libeuclid-cdk.so` |
| `EUCLID_CDK_BUILD_STATIC` | `ON` | build `libeuclid-cdk.a` |
| `EUCLID_CDK_BUILD_TESTS` | top-level only | build and register the tests |
| `EUCLID_CDK_BUILD_EXAMPLES` | top-level only | build `eam-walkthrough` |
| `EUCLID_CDK_INSTALL` | top-level only | generate the install and package-config targets |

Both libraries are compiled from the same sources twice rather than shared through an object
library: the export macros differ between them, and on Windows a static library with
`__declspec(dllexport)` in it is not usable.

### Tests

The tests run a euclid server in-process (`tests/FakeGateway`) that verifies every signed request
with the same rules the real one applies, so a client that signs one thing and sends another fails
there rather than in production. They point `EUCLID_CREDENTIALS_FILE` at a scratch file for the
duration, and so never touch a real `~/.euclid/credentials`.

Behind it, `tests/FakeStorage` is a storage module small enough to read: an upload assembles its
parts in part order and a download hands back the byte range that was asked for. The part of a
multipart transfer a unit test cannot see is exactly the part that corrupts an object — a part
number off by one, a part size the two ends disagree about — so the transfers are checked against
something that actually reassembles what it is sent.

### Examples

```bash
./build/examples/eam-walkthrough        https://euclid.example.com jens secret [namespace]
./build/examples/esm-walkthrough        https://euclid.example.com jens secret [namespace]
./build/examples/messaging-walkthrough  https://euclid.example.com jens secret [namespace]
./build/examples/monitoring-walkthrough https://euclid.example.com jens secret [namespace]
```

The EAM one reads only, apart from the namespace it switches to when one is given. The storage and
messaging ones work in resources of their own, named after the moment they started, and delete them
again at the end — so a run that dies halfway leaves something obviously disposable behind rather
than touching anything of yours. The messaging one is both modules at once: a topic, a queue
subscribed to it, and a message that travels.

The monitoring one records and publishes a run of made-up work, then reads the rows back if the
login may. It is the one that cannot clean up after itself — there is no delete for a metric, and
they go when EMO's retention takes them — so it reports under a module name of its own rather than
into anything you would recognise. It is also the clearest demonstration of what a step is: it
prints what the run counted beside what the meters still hold, and the two differ by exactly what
the publisher already took.

## Licence

Apache-2.0. The euclid server itself is MPL-2.0; the SDKs are not, matching euclid-jdk, euclid-pdk
and euclid-ndk.
