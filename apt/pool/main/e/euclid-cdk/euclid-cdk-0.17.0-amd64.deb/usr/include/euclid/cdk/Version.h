// SPDX-License-Identifier: Apache-2.0
//
// Generated from cmake/Version.h.in - do not edit. The version lives in version.txt.

#pragma once

// C++ includes
#include <string_view>

namespace Euclid::CDK {

    /**
     * @brief The version of this SDK, e.g. "0.1.0".
     */
    inline constexpr std::string_view Version = "0.17.0";

    /**
     * @brief Major version number.
     */
    inline constexpr int VersionMajor = 0;

    /**
     * @brief Minor version number.
     */
    inline constexpr int VersionMinor = 17;

    /**
     * @brief Patch version number.
     */
    inline constexpr int VersionPatch = 0;

    /**
     * @brief What this SDK sends as its User-Agent, e.g. "euclid-cdk/0.1.0".
     */
    inline constexpr std::string_view UserAgent = "euclid-cdk/0.17.0";

}// namespace Euclid::CDK
