#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "euclid::cdk" for configuration "Release"
set_property(TARGET euclid::cdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(euclid::cdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libeuclid-cdk.so.0.17.0"
  IMPORTED_SONAME_RELEASE "libeuclid-cdk.so.0"
  )

list(APPEND _cmake_import_check_targets euclid::cdk )
list(APPEND _cmake_import_check_files_for_euclid::cdk "${_IMPORT_PREFIX}/lib/libeuclid-cdk.so.0.17.0" )

# Import target "euclid::cdk-static" for configuration "Release"
set_property(TARGET euclid::cdk-static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(euclid::cdk-static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libeuclid-cdk.a"
  )

list(APPEND _cmake_import_check_targets euclid::cdk-static )
list(APPEND _cmake_import_check_files_for_euclid::cdk-static "${_IMPORT_PREFIX}/lib/libeuclid-cdk.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
