
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was euclid-cdk-config.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

# Boost and OpenSSL are PUBLIC/PRIVATE link dependencies of the exported targets, so a consumer has
# to be able to resolve them before the target file below can be included.
# Header-only Boost libraries are reached through Boost::headers rather than by name: whether an
# install defines Boost::asio at all depends on how it was packaged - vcpkg does, an upstream or
# distro install does not - and asking for one it has not got fails here, in euclid-cdk's own
# configuration file, where a consumer can do nothing about it. Boost::headers exists in both.
find_dependency(Boost CONFIG COMPONENTS headers json url)
find_dependency(OpenSSL COMPONENTS SSL Crypto)
find_dependency(Threads)

include("${CMAKE_CURRENT_LIST_DIR}/euclid-cdk-targets.cmake")

check_required_components(euclid-cdk)
