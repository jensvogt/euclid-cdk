// SPDX-License-Identifier: Apache-2.0

#pragma once

// C++ includes
#include <string>
#include <vector>

// Boost includes
#include <boost/json.hpp>

// Euclid includes
#include <euclid/cdk/Export.h>
#include <euclid/cdk/Json.h>
#include <euclid/cdk/dto/Page.h>

/**
 * @file
 * @brief The shapes EAM sends back, and the readers that parse them.
 *
 * @par
 * Structs rather than raw boost::json::value, so a typo in a field name is a compile error here
 * instead of a null that travels. Field names are the server's own
 * (dto/include/euclid/dto/eam in the euclid repository), which is why some of them read oddly in
 * C++: "ns" is the C++ spelling of a field the wire calls "namespace", because the wire name is a
 * keyword here.
 */

namespace Euclid::CDK::EAM {

    // Paging is the same in every module, so it is described once in dto/Page.h - named here as
    // well, since EAM::Page<User> is what a caller of ListUsers() reads in the signature.
    using CDK::Page;
    using CDK::ToPage;

    /**
     * @brief The caller identity a response echoes back, from the server's BaseDto.
     */
    struct EUCLID_CDK_API Metadata {
        std::string region;
        std::string accountId;
        std::string user;
    };

    /**
     * @brief A signing credential. The secret is returned once, at creation, and never again.
     */
    struct EUCLID_CDK_API AccessKey {
        std::string accessKeyId;
        bool active{true};
        std::string createdAt;
    };

    /**
     * @brief One role, given to one principal, somewhere.
     *
     * @par
     * The only thing that grants anything, and the only thing that carries scope. Replaced the
     * per-user accountGrants/resourceGrants lists: what a user may do is the union of the grants
     * held by them and by every group they belong to.
     *
     * @par
     * "grantId" is what Session::RevokeRole() takes - not the (role, principal) pair, since the
     * same role may be granted to the same principal twice with different scope, and revoking has
     * to say which.
     */
    struct EUCLID_CDK_API Grant {
        std::string grantId;
        std::string role;
        std::string principal;
        std::string accountId;
        std::vector<std::string> namespaces;
        std::vector<std::string> resources;
        std::string granted;
        std::string grantedBy;
    };

    /**
     * @brief A role: a name, and the permissions it carries.
     *
     * @par
     * What a grant binds to a principal. The permissions are "<module>:<action>" pairs, and the
     * whole set of them is what Session::ListPermissions() answers.
     *
     * @par
     * "builtin" separates the roles euclid ships - "account-administrator", "operator", "reader",
     * "publisher", "consumer", "application" - from an account's own. A built-in one belongs to no
     * account's storage and cannot be changed or deleted; it still describes itself with the asking
     * account's ID and region, because that is the account the grant would be made in.
     */
    struct EUCLID_CDK_API Role {
        std::string name;
        std::string ern;
        std::string accountId;
        std::string region;
        std::string description;

        /**
         * @brief The permissions this role carries, as "<module>:<action>".
         */
        std::vector<std::string> permissions;

        /**
         * @brief Whether euclid ships this role rather than the account defining it.
         */
        bool builtin{};
        std::string created;
        std::string modified;
    };

    /**
     * @brief A user. "password" is a hash when the server sends one at all - never the plaintext.
     */
    struct EUCLID_CDK_API User {
        std::string userId;
        std::string ern;
        std::string password;
        std::string email;
        std::string accountId;
        std::string region;
        std::string created;
        std::string modified;
    };

    /**
     * @brief A named set of users. Membership in the "administrator" group is what makes an admin.
     */
    struct EUCLID_CDK_API UserGroup {
        std::string name;
        std::string ern;
        std::string accountId;
        std::string region;
        std::string description;
        std::vector<std::string> userIds;
        std::string created;
        std::string modified;
    };

    /**
     * @brief A tenant. Namespaces live under it, and everything else is scoped by the pair.
     */
    struct EUCLID_CDK_API Account {
        std::string accountId;
        std::string name;
        std::string ern;
        std::string description;
        std::string created;
        std::string modified;
    };

    /**
     * @brief A namespace within an account, unique by name within it.
     */
    struct EUCLID_CDK_API Namespace {
        std::string accountId;
        std::string name;
        std::string ern;
        std::string description;
        std::string created;
        std::string modified;
    };

    /**
     * @brief What "login" answers with: a bearer token and, usually, an access key to sign with.
     */
    struct EUCLID_CDK_API LoginResult {
        std::string token;
        std::string accessKeyId;
        std::string secretAccessKey;
        std::string createdAt;
        bool isAdmin{false};
        Metadata metadata;

        /**
         * @brief The response as it arrived, for anything a later euclid added that this does not
         * name.
         */
        boost::json::object raw;
    };

    /**
     * @brief The accounts a session may work in, and which one is its own.
     *
     * @par
     * "homeAccountId" is the account the user belongs to; the list is that one plus every account
     * they hold a grant in, de-duplicated and ordered - a user with several grants in one account
     * sees it once, and the order does not depend on which grant was written first. For an
     * administrator it is every account in the installation.
     *
     * @par
     * An account the user can reach but which has no record of its own is listed named after its
     * own ID rather than blank, because a row with nothing in it is worse than one showing the id a
     * client is about to send.
     */
    struct EUCLID_CDK_API MyAccounts {
        std::string homeAccountId;
        std::vector<Account> accounts;
        long total{};
    };

    /**
     * @brief A newly created access key. This is the only time the secret is ever returned.
     */
    struct EUCLID_CDK_API CreateAccessKeyResult {
        std::string accessKeyId;
        std::string secretAccessKey;
        std::string createdAt;
        Metadata metadata;
    };

    /**
     * @brief Reads a "metadata" object.
     */
    [[nodiscard]]
    EUCLID_CDK_API Metadata ToMetadata(const boost::json::value &value);

    /**
     * @brief Reads an access key.
     */
    [[nodiscard]]
    EUCLID_CDK_API AccessKey ToAccessKey(const boost::json::value &value);

    /**
     * @brief Reads a grant.
     */
    [[nodiscard]]
    EUCLID_CDK_API Grant ToGrant(const boost::json::value &value);

    /**
     * @brief Reads a role.
     */
    [[nodiscard]]
    EUCLID_CDK_API Role ToRole(const boost::json::value &value);

    /**
     * @brief Reads a user.
     */
    [[nodiscard]]
    EUCLID_CDK_API User ToUser(const boost::json::value &value);

    /**
     * @brief Reads a user group.
     */
    [[nodiscard]]
    EUCLID_CDK_API UserGroup ToUserGroup(const boost::json::value &value);

    /**
     * @brief Reads an account.
     */
    [[nodiscard]]
    EUCLID_CDK_API Account ToAccount(const boost::json::value &value);

    /**
     * @brief Reads a namespace.
     */
    [[nodiscard]]
    EUCLID_CDK_API Namespace ToNamespace(const boost::json::value &value);

    /**
     * @brief Reads a list-my-accounts response.
     */
    [[nodiscard]]
    EUCLID_CDK_API MyAccounts ToMyAccounts(const boost::json::value &value);

    /**
     * @brief Reads a login response.
     */
    [[nodiscard]]
    EUCLID_CDK_API LoginResult ToLoginResult(const boost::json::value &value);

    /**
     * @brief Reads a create-access-key response.
     */
    [[nodiscard]]
    EUCLID_CDK_API CreateAccessKeyResult ToCreateAccessKeyResult(const boost::json::value &value);

}// namespace Euclid::CDK::EAM
